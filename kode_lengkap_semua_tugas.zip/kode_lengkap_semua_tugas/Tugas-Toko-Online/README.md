# Tugas Program Toko Online — Laravel + MySQL

Mencakup pengunjung dapat melihat produk tanpa login; login/register; pembelian wajib login; keranjang; validasi stok; checkout membuat pesanan dan detail; stok berkurang; keranjang dikosongkan; riwayat pesanan.

Buat proyek:
```bash
composer create-project laravel/laravel:^13.0 toko-online
cd toko-online
```
Buat database `db_toko_online`, atur `.env`, lalu salin file paket ke proyek. Pastikan migration users bawaan diganti dengan migration users pada paket ini. Jalankan:
```bash
php artisan optimize:clear
php artisan migrate:fresh --seed
php artisan serve
```
Akun demo: `budi` / `password123`. Pengunjung dapat membuka katalog; untuk membeli, daftar akun atau login.
