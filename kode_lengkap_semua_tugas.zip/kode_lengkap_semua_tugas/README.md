# Kode Lengkap Tugas Penyimpanan Data Web

Isi:
1. `Tugas1-Login-Laravel13` — login Laravel 13 dengan password hash, middleware auth/guest, dashboard, logout.
2. `Tugas2-Keranjang-Session` — keranjang tanpa login memakai Laravel Session dan MySQL.
3. `Tugas-Toko-Online` — toko online dengan login, katalog, keranjang, checkout, pengurangan stok, riwayat pesanan.
4. `Modul-Demo-PHP-JS` — demo HTTP stateless, cookies, session, dan Local Storage.

## Cara menggunakan proyek Laravel
Folder dalam ZIP berisi file yang perlu ditambahkan/ditimpa pada proyek Laravel baru, bukan folder `vendor` atau seluruh framework.

Persyaratan umum: PHP 8.3+, Composer, MySQL, dan ekstensi PHP yang dibutuhkan Laravel.

Untuk setiap proyek Laravel:
1. Buka terminal pada folder induk.
2. Buat proyek baru sesuai instruksi di README masing-masing.
3. Salin isi folder paket ke proyek Laravel, dengan mempertahankan struktur direktori.
4. Buat database sesuai nama di `.env`.
5. Jalankan `php artisan migrate --seed`.
6. Jalankan `php artisan serve`.

Jangan menyalin folder `vendor` dari proyek lain. Jalankan `composer install` bila diperlukan.
