# Tugas 2 — Keranjang Belanja Tanpa Login (Laravel + Session)

Buat proyek Laravel (Laravel 11/12/13 dapat digunakan):
```bash
composer create-project laravel/laravel:^13.0 tugas2
cd tugas2
```
Buat database `db_tugas2`, atur `.env` MySQL, lalu salin file paket ini ke proyek. Jalankan:
```bash
php artisan optimize:clear
php artisan migrate --seed
php artisan serve
```
Buka `http://127.0.0.1:8000`. Data keranjang disimpan di Session server; session tetap ada ketika halaman di-refresh dan biasanya hilang ketika session berakhir.
