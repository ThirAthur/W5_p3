# Tugas 1 — Login dengan Password Terenkripsi (Laravel 13)

Buat proyek:
```bash
composer create-project laravel/laravel:^13.0 tugas1
cd tugas1
```
Buat database MySQL bernama `db_tugas`, atur `.env`:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=db_tugas
DB_USERNAME=root
DB_PASSWORD=
```
Salin file dalam paket ini ke proyek. Pada instalasi Laravel baru, sesuaikan/ganti migration users bawaan agar tidak membuat kolom email. Lalu:
```bash
php artisan optimize:clear
php artisan migrate:fresh --seed
php artisan serve
```
Akun seeder: `budi` / `password123`, dan `siti` / `password123`.
