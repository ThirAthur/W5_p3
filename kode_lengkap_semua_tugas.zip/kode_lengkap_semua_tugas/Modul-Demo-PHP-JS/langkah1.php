<!doctype html><html lang="id"><meta charset="utf-8"><title>Langkah 1</title>
<body><h2>Langkah 1: Perkenalkan diri</h2><form method="post" action="langkah2.php">
<input name="nama" placeholder="Nama Anda" required><button>Kirim ke server</button></form></body></html>
