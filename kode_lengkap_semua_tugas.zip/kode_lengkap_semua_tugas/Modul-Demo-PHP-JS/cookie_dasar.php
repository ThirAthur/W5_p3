<?php
if (isset($_POST['nama']) && trim($_POST['nama']) !== '') {
    setcookie('nama', trim($_POST['nama']), ['expires' => time() + 7*86400, 'path' => '/', 'samesite' => 'Lax']);
    header('Location: cookie_dasar.php'); exit;
}
if (isset($_GET['hapus'])) {
    setcookie('nama', '', ['expires' => time()-3600, 'path' => '/', 'samesite' => 'Lax']);
    header('Location: cookie_dasar.php'); exit;
}
$kunjungan = (int)($_COOKIE['kunjungan'] ?? 0) + 1;
setcookie('kunjungan', (string)$kunjungan, ['expires' => time()+7*86400, 'path' => '/', 'samesite' => 'Lax']);
$nama = $_COOKIE['nama'] ?? null;
?>
<!doctype html><html lang="id"><meta charset="utf-8"><title>Cookie Dasar</title><body>
<?php if ($nama): ?><h1>Halo, <?= htmlspecialchars($nama) ?>!</h1><p>Kunjungan: <?= $kunjungan ?></p><a href="?hapus=1">Lupakan saya</a>
<?php else: ?><h1>Halo, tamu!</h1><form method="post"><input name="nama" placeholder="Nama Anda" required><button>Simpan</button></form><?php endif; ?>
</body></html>
