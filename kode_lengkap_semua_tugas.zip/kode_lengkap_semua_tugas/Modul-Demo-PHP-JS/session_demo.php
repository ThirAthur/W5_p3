<?php
session_start();
if (isset($_POST['nama'])) $_SESSION['nama'] = trim($_POST['nama']);
if (isset($_GET['hapus'])) { session_unset(); session_destroy(); header('Location: session_demo.php'); exit; }
?>
<!doctype html><html lang="id"><meta charset="utf-8"><title>Demo Session</title><body>
<h1>Demo PHP Session</h1>
<?php if (!empty($_SESSION['nama'])): ?><p>Halo, <?= htmlspecialchars($_SESSION['nama']) ?>. Data disimpan di session server.</p><a href="?hapus=1">Hapus session</a>
<?php else: ?><form method="post"><input name="nama" placeholder="Nama Anda" required><button>Simpan nama</button></form><?php endif; ?>
</body></html>
