<?php $nama = $_POST['nama'] ?? null; ?>
<!doctype html><html lang="id"><meta charset="utf-8"><title>Langkah 2</title><body>
<h2>Langkah 2: Server menerima data</h2><p>Halo, <b><?= htmlspecialchars($nama ?? 'tidak diketahui') ?></b>!</p>
<a href="langkah3.php">Lanjut ke Langkah 3</a></body></html>
