<?php $nama = $_POST['nama'] ?? null; ?>
<!doctype html><html lang="id"><meta charset="utf-8"><title>Langkah 3</title><body>
<h2>Langkah 3: Apakah server masih ingat?</h2><p>Halo, <b><?= htmlspecialchars($nama ?? 'tidak diketahui') ?></b>.</p>
<p>Request baru tidak otomatis membawa data dari request sebelumnya.</p></body></html>
