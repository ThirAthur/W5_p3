<?php
$produk = [1=>['nama'=>'Buku Tulis','harga'=>5000],2=>['nama'=>'Pulpen','harga'=>3000],3=>['nama'=>'Penggaris','harga'=>4000]];
$cart = json_decode($_COOKIE['keranjang'] ?? '{}', true);
if (!is_array($cart)) $cart = [];
if (isset($_GET['tambah'])) {
    $id=(int)$_GET['tambah'];
    if (isset($produk[$id])) $cart[$id]=(int)($cart[$id]??0)+1;
    setcookie('keranjang', json_encode($cart), ['expires'=>time()+3600,'path'=>'/','samesite'=>'Lax']);
    header('Location: keranjang_cookie.php'); exit;
}
if (isset($_GET['kosongkan'])) {
    setcookie('keranjang','',['expires'=>time()-3600,'path'=>'/']);
    header('Location: keranjang_cookie.php'); exit;
}
?>
<!doctype html><html lang="id"><meta charset="utf-8"><title>Keranjang Cookies</title><body>
<h1>Daftar Produk</h1><ul><?php foreach($produk as $id=>$p): ?><li><?= htmlspecialchars($p['nama']) ?> — Rp <?= number_format($p['harga'],0,',','.') ?> <a href="?tambah=<?= $id ?>">[Tambah]</a></li><?php endforeach; ?></ul>
<h2>Keranjang Anda</h2><?php $total=0; ?><ul>
<?php foreach($cart as $id=>$qty): if(!isset($produk[$id])) continue; $sub=$produk[$id]['harga']*(int)$qty; $total+=$sub; ?>
<li><?= htmlspecialchars($produk[$id]['nama']) ?> × <?= (int)$qty ?> = Rp <?= number_format($sub,0,',','.') ?></li>
<?php endforeach; ?></ul><p>Total: Rp <?= number_format($total,0,',','.') ?></p><a href="?kosongkan=1">Kosongkan keranjang</a>
</body></html>
