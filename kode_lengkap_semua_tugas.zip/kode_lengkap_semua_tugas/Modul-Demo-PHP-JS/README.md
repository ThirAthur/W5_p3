# Demo Modul Penyimpanan Data pada Web

Ini adalah demo kecil yang terpisah dari proyek Laravel. Jalankan dengan PHP 8.3:
```bash
cd Modul-Demo-PHP-JS
php -S localhost:8000
```
Lalu buka `http://localhost:8000/langkah1.php`, `cookie_dasar.php`, `keranjang_cookie.php`, `session_demo.php`, `tema.html`, `keranjang_ls.html`, dan `storage_beda.html`.
